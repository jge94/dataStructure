// function declaration prototypes

void getData   (short A[],  short& hmr);	

void printData (const short A[],  short hmr);	

void  getStats  (const short A[],  short hmr, 
                 short& max, short& min, double& mean, 
                 short& whereMax, short& whereMin );


