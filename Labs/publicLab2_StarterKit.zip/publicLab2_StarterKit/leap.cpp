
#include <iostream>

using namespace std;

int main(void)
{
    short year;	// user-entered year
    
    cout << "Enter an integer year >> ";
    cin  >> year;
    
    cout << endl;
    cout << "The year " << year;
    
    // YOU write the expression for the IF statement
    
    if (   )
		cout << " IS a leap year." << endl;
    else
		cout << " is NOT a leap year." << endl;
	
	
	return 0;
	
}  // main