// ============ insert this code inside main() ==============

#include <iostream>
#include <cassert>

using namespace std;


const char BEEP = char(7);



short i,sum;

const short N=5;

i   =    ;
sum =    ;

while(   )       // INV: sum == 0 + 1 + 2 + ... + (i-1)  &&  1 <= i <= N+1
{
	
	
	
}

// you may NOT change this assertion
assert(sum == N/2.0*(N+1)  && i == N+1);

// if assert doesn't work  :(
// then uncomment the following:
/*
if (! (sum == N/2.0*(N+1)  && i == N+1)  )
{
	cout << "ASSERT FAILED!" << endl;
    //system("PAUSE");
    exit(-1);
}
*/


cout << "\n\n**** sum is " << sum << endl;


