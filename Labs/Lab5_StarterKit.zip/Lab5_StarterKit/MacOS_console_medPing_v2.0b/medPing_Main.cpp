/*--------------------------------------------------------------
Programmer:
Summary:
Date last modified:
----------------------------------------------------------------*/

/*--------------------------------------------------------------
INPUT:
OUTPUT:
---------------------------------------------------------------*/


#include "medPing.h"


//--------------
// medPing_Main \
//----------------------------------------------------------------------
int medPing_Main()
{
	// create a medPing object
	medPing mP;


	// print a message to the cell phone

	mP.CELL_PrintF("\nHello medPing patient ...\n\n");



	return 0;

} // end medPing_Main()
