#include "mp_InputOutput.h"
#include "medPing.h"

//================================================================
// Programmer: 
//
// Summary: 
//
// Modification History:
//    12/15/08 -- (mdl) medPing lives ...
//    12/31/13 -- (mdl) medPing resuscitated ... 
//
//================================================================


// Don't change this; all intro work should be done in medPing_Main()

int main (int argc, char * const argv[])
{
	medPing_Main();
	
	return 0;
}
