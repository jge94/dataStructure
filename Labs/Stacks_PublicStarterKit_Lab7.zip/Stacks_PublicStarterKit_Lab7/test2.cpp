int main()
{
    short x=0, y=8;
    x=((y+x)*3);
    y = (y*3));
    
    y = (x*3)) - (x*x));
    
    cout << ((x+y);
    
    return 0;
}